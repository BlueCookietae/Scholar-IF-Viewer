/**
 * [Scholar IF & Renamer] 통합 컨텐츠 스크립트 (Strict Match + Not Found Info)
 * - 수정 사항: API 검색엔 성공했으나 DB에 없는 경우 "IF DB match not found" 표시 및 툴팁 제공.
 * - 로직:
 * 1. 텍스트 추출 및 정제
 * 2. 동기 완전 일치 시도
 * 3. 실패 시 API 호출 -> 결과가 DB에 있으면 IF 표시 / DB에 없으면 "Not Found" 표시 (Fuzzy 안함)
 * 4. API 실패 시에만 잘린 텍스트로 운 좋은 일치 시도
 */

const apiCache = new Map();

// 한국어 포함 여부 체크
function containsKorean(text) {
    return /[ㄱ-ㅎㅏ-ㅣ가-힣]/.test(text);
}

// 1. 학술지 이름 정규화
function normalizeName(name) {
    if (!name) return "";
    return name.toUpperCase()
        .replace(/&/g, "AND")
        .replace(/\bTHE\b|\bOF\b|\bAND\b|\bFOR\b/g, "")
        .replace(/[\u2026]|\.{3}/g, "")
        .replace(/[^A-Z0-9]/g, "")
        .trim();
}

// 2. CrossRef API (Top-1 결과만 반환)
async function fetchFullJournalName(paperTitle) {
    if (!paperTitle) return null;
    if (apiCache.has(paperTitle)) return apiCache.get(paperTitle);

    try {
        const url = `https://api.crossref.org/works?query.title=${encodeURIComponent(paperTitle)}&rows=1`;
        const response = await fetch(url, { cache: "force-cache" });
        const data = await response.json();
        
        if (data.status === "ok" && data.message.items.length > 0) {
            const item = data.message.items[0];
            const journalName = item['container-title']?.[0];
            
            if (journalName) {
                apiCache.set(paperTitle, journalName);
                return journalName;
            }
        }
    } catch (err) {
        return null;
    }
    return null;
}

// [기능 1] Impact Factor 표시 로직
async function injectIF() {
    try {
        const response = await fetch(chrome.runtime.getURL('data.json'));
        const ifData = await response.json();
        
        const normalizedDB = {};
        for (const key in ifData) {
            const normKey = normalizeName(key);
            normalizedDB[normKey] = { ...ifData[key], originalName: key };
        }

        const rows = document.querySelectorAll('.gs_r.gs_or.gs_scl, .gsc_a_tr'); 
        
        rows.forEach(async (row) => {
            let infoRow, titleNode, paperTitle, journalCandidate, isTruncated = false;

            if (row.getAttribute('data-if-processed') === 'true') return;
            if (row.querySelector('.scholar-if-display')) return;

            // 구글 스칼라 검색 결과
            if (row.classList.contains('gs_r')) {
                infoRow = row.querySelector('.gs_a');
                titleNode = row.querySelector('.gs_rt a');
                if (!infoRow) return;

                const text = infoRow.innerText;
                const parts = text.split(/[–—\-]/).map(p => p.trim());
                paperTitle = titleNode ? titleNode.innerText : "";
                isTruncated = text.includes('…') || text.includes('...');

                if (parts.length >= 2) {
                    journalCandidate = parts[1].split(',')[0].trim();
                    if (/^\d{4}$/.test(journalCandidate) && parts[2]) {
                        journalCandidate = parts[2].split(',')[0].trim();
                    }
                }
            } 
            // 구글 스칼라 프로필
            else if (row.classList.contains('gsc_a_tr')) {
                const infoDivs = row.querySelectorAll('.gsc_a_t .gs_gray');
                if (infoDivs.length < 2) return;
                
                infoRow = infoDivs[1];
                titleNode = row.querySelector('.gsc_a_at');
                paperTitle = titleNode ? titleNode.innerText : "";
                journalCandidate = infoRow.innerText.split(',')[0].trim();
                isTruncated = infoRow.innerText.includes('…') || infoRow.innerText.includes('...');
            }

            if (!journalCandidate || !infoRow) return;
            if (containsKorean(paperTitle) || containsKorean(journalCandidate)) {
                row.setAttribute('data-if-processed', 'true');
                return;
            }

            if (journalCandidate) {
                journalCandidate = journalCandidate.replace(/\s+(\d+(\s*\(\d+\))?|\(\d+\))$/, "").trim();
            }

            row.setAttribute('data-if-processed', 'true');

            let matches = [];
            let apiResultName = null; // API가 찾은 이름을 저장할 변수
            const normalizedJournal = normalizeName(journalCandidate);

            const findExact = (normName) => normalizedDB[normName] || null;
            const findFuzzy = (normName) => {
                if (!normName || normName.length < 4) return null;
                const prefixKey = Object.keys(normalizedDB).find(key => key.startsWith(normName));
                if (prefixKey) return normalizedDB[prefixKey];
                const fuzzyKey = Object.keys(normalizedDB).find(key => {
                    if (key.length > 15 && normName.length > 15) {
                        return key.includes(normName) || normName.includes(key);
                    }
                    return false;
                });
                return fuzzyKey ? normalizedDB[fuzzyKey] : null;
            };

            // [Step 1] 동기 매칭
            if (!isTruncated) {
                const exactMatch = findExact(normalizedJournal);
                if (exactMatch) matches.push(exactMatch);
            }

            // [Step 2] API 어시스트
            if (matches.length === 0 && paperTitle) {
                const apiJournalName = await fetchFullJournalName(paperTitle);
                
                if (apiJournalName) {
                    apiResultName = apiJournalName; // API 결과 저장
                    const match = findExact(normalizeName(apiJournalName));
                    if (match) {
                        matches.push(match);
                    }
                    // API가 결과를 줬지만 DB에 없는 경우, matches는 비어있고 apiResultName은 존재함
                    // 이 경우 Step 3(Fuzzy)로 넘어가지 않고 "Not Found"를 띄우기 위해 여기서 종료됨
                } else {
                    // API 실패 시에만 Step 3 시도
                    if (matches.length === 0 && isTruncated) {
                        const luckyMatch = findExact(normalizedJournal);
                        if (luckyMatch) matches.push(luckyMatch);
                        else {
                            const fuzzyMatch = findFuzzy(normalizedJournal);
                            if (fuzzyMatch) matches.push(fuzzyMatch);
                        }
                    }
                }
            }

            // UI 렌더링
            const resContainer = document.createElement('span');
            resContainer.className = 'scholar-if-display';
            resContainer.style.marginLeft = '8px';
            resContainer.style.display = 'inline-flex';
            resContainer.style.alignItems = 'center';

            if (matches.length >= 1) {
                const m = matches[0];
                
                const ifText = document.createElement('span');
                ifText.style.color = '#d93025';
                ifText.style.fontWeight = 'bold';
                ifText.style.fontSize = '12px';
                ifText.style.cursor = 'help';
                ifText.innerText = `IF ${m.if}`;
                ifText.title = `[매칭된 저널: ${m.originalName}]`; 
                resContainer.appendChild(ifText);

                if (m.q === 'Q1' && m.rank && m.rank.includes('/')) {
                    const [rank, total] = m.rank.split('/').map(num => parseInt(num.trim()));
                    if (!isNaN(rank) && !isNaN(total)) {
                        const topPercent = Math.ceil((rank / total) * 100);
                        
                        const q1Badge = document.createElement('span');
                        q1Badge.style.background = 'linear-gradient(135deg, #FFD700 0%, #FDB931 25%, #FFFACD 50%, #FDB931 75%, #FFD700 100%)';
                        q1Badge.style.backgroundSize = '200% auto';
                        q1Badge.style.border = '1px solid #DAA520';
                        q1Badge.style.color = '#000000';
                        q1Badge.style.padding = '1px 6px';
                        q1Badge.style.borderRadius = '4px';
                        q1Badge.style.fontSize = '10px';
                        q1Badge.style.fontWeight = '800';
                        q1Badge.style.marginLeft = '6px';
                        q1Badge.style.boxShadow = '0 1px 3px rgba(0,0,0,0.2), inset 0 1px 0 rgba(255,255,255,0.4)';
                        q1Badge.style.textShadow = '0.5px 0.5px 0px rgba(255,255,255,0.5)';
                        q1Badge.style.whiteSpace = 'nowrap';
                        q1Badge.style.cursor = 'help';
                        q1Badge.innerText = `TOP ${topPercent}%`;
                        q1Badge.title = `[매칭된 저널: ${m.originalName}] (순위: ${m.rank})`;
                        resContainer.appendChild(q1Badge);
                    }
                }
                infoRow.appendChild(resContainer);
            } 
            // [NEW] 매칭 실패했지만 API 결과는 있는 경우 ("Not Found" 표시)
            else if (apiResultName) {
                const notFoundSpan = document.createElement('span');
                notFoundSpan.style.color = '#999';
                notFoundSpan.style.fontSize = '11px';
                notFoundSpan.style.cursor = 'help';
                // 점선 밑줄 추가로 툴팁이 있음을 암시
                notFoundSpan.style.borderBottom = '1px dotted #ccc'; 
                notFoundSpan.innerText = 'IF DB match not found';
                
                // 툴팁에 API가 찾아낸 풀네임 표시
                notFoundSpan.title = `API Result: ${apiResultName}\n(Database에 해당 저널의 IF 정보가 없습니다)`;
                
                resContainer.appendChild(notFoundSpan);
                infoRow.appendChild(resContainer);
            }
        });
    } catch (err) {}
}

function extractPaperTitle() {
    if (!chrome.runtime?.id) return;
    let info = { title: null };
    const getMeta = (keys) => {
        for (let key of keys) {
            const el = document.querySelector(`meta[name="${key}"], meta[property="${key}"]`);
            if (el && el.getAttribute('content')) return el.getAttribute('content').trim();
        }
        return null;
    };
    info.title = getMeta(['citation_title', 'dc.title', 'og:title']);
    if (!info.title) {
        const gsTitle = document.querySelector('#gsc_oci_title');
        if (gsTitle) info.title = gsTitle.innerText.trim();
        else {
            const h1 = document.querySelector('h1');
            if (h1) info.title = h1.innerText.trim();
        }
    }
    if (info.title) {
        const cleanTitle = info.title.replace(/[\u200B-\u200D\uFEFF\u202A-\u202E]/g, "").replace(/\s+/g, " ").trim();
        try {
            chrome.runtime.sendMessage({ type: 'PAPER_TITLE_EXTRACTED', title: cleanTitle });
        } catch (e) {}
    }
}

injectIF();
extractPaperTitle();

let timeout = null;
const observer = new MutationObserver(() => {
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(() => {
        injectIF();
        extractPaperTitle();
    }, 200);
});
observer.observe(document.body, { childList: true, subtree: true });